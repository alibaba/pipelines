# The default Data of training job
default_data = 'None'

def set_defaultData(data):
	default_data = data

def get_defaultData():
	return default_data